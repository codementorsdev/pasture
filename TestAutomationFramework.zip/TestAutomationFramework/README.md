# Enterprise Test Automation Framework

A modular, plugin-based test automation framework built with Java Spring Boot that supports multiple testing types through a unified architecture.

## 🚀 Features

- **Multi-Type Testing Support**: UI, API, Database, Performance, and ETL testing
- **Plugin Architecture**: Extensible plugin system using Spring SPI
- **Parallel Execution**: Intelligent test orchestration with parallel execution
- **Unified Reporting**: Consolidated reports across all test types (JSON, XML, HTML)
- **REST API & CLI**: Both programmatic and command-line interfaces
- **Docker Support**: Containerized execution environment
- **Spring Boot Integration**: Enterprise-ready with Spring Boot 3.x

## 📋 Supported Test Types

| Test Type | Plugin | Description |
|-----------|--------|-------------|
| UI Testing | Selenium UI Plugin | Web browser automation with Chrome/Firefox |
| API Testing | RestAssured Plugin | RESTful API testing with JSON/XML validation |
| Database Testing | JDBC Plugin | SQL execution and database validation |
| Performance Testing | JMeter Plugin | Load and performance testing (planned) |
| ETL Testing | Data Validation Plugin | Data pipeline validation (planned) |

## 🏗️ Architecture

