package com.enterprise.testframework;

import com.enterprise.testframework.cli.TestFrameworkCLI;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.plugin.core.config.EnablePluginRegistries;

/**
 * Main application class for the Enterprise Test Automation Framework
 * Supports both CLI and REST API modes
 */
@SpringBootApplication
@ComponentScan(basePackages = {
    "com.enterprise.testframework",
    "com.enterprise.testframework.plugins"
})
@EnablePluginRegistries({
    com.enterprise.testframework.interfaces.IRunnerPlugin.class,
    com.enterprise.testframework.interfaces.IReportingPlugin.class,
    com.enterprise.testframework.interfaces.ITestTypeClassifier.class
})
public class TestFrameworkApplication {

    public static void main(String[] args) {
        // Check if CLI mode is requested
        if (args.length > 0 && !args[0].startsWith("--server")) {
            // CLI mode
            ApplicationContext context = SpringApplication.run(TestFrameworkApplication.class, args);
            TestFrameworkCLI cli = context.getBean(TestFrameworkCLI.class);
            cli.run(args);
        } else {
            // Server mode (REST API)
            SpringApplication.run(TestFrameworkApplication.class, args);
        }
    }
}
