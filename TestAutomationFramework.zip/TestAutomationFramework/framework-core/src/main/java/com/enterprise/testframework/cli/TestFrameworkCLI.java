package com.enterprise.testframework.cli;

import com.enterprise.testframework.core.PluginManager;
import com.enterprise.testframework.core.TestDiscoveryService;
import com.enterprise.testframework.core.TestExecutionOrchestrator;
import com.enterprise.testframework.model.TestCase;
import com.enterprise.testframework.model.TestConfig;
import com.enterprise.testframework.model.TestRunResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;
import picocli.CommandLine.Parameters;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Command line interface for the test framework
 */
@Component
@Command(name = "test-framework", mixinStandardHelpOptions = true, version = "1.0.0",
         description = "Enterprise Test Automation Framework CLI")
public class TestFrameworkCLI implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(TestFrameworkCLI.class);

    @Autowired
    private TestExecutionOrchestrator orchestrator;

    @Autowired
    private TestDiscoveryService discoveryService;

    @Autowired
    private PluginManager pluginManager;

    @Option(names = {"-d", "--directory"}, description = "Directory containing test files")
    private String testDirectory;

    @Option(names = {"-f", "--files"}, description = "Comma-separated list of test files", split = ",")
    private List<String> testFiles;

    @Option(names = {"-t", "--type"}, description = "Test type filter (ui, api, database, performance, etl)")
    private String testType;

    @Option(names = {"-e", "--environment"}, description = "Test environment", defaultValue = "test")
    private String environment;

    @Option(names = {"-p", "--parallel"}, description = "Enable parallel execution", defaultValue = "true")
    private boolean parallel;

    @Option(names = {"-c", "--concurrency"}, description = "Maximum concurrency level", defaultValue = "4")
    private int maxConcurrency;

    @Option(names = {"--continue-on-failure"}, description = "Continue execution on test failures")
    private boolean continueOnFailure;

    @Option(names = {"--report-format"}, description = "Report format (json, xml, html)", defaultValue = "json")
    private String reportFormat;

    @Option(names = {"--report-dir"}, description = "Report output directory", defaultValue = "./reports")
    private String reportDir;

    @Option(names = {"--list-plugins"}, description = "List available plugins")
    private boolean listPlugins;

    @Option(names = {"--list-test-types"}, description = "List supported test types")
    private boolean listTestTypes;

    @Parameters(description = "Command to execute (run, discover, list)")
    private String command;

    public void run(String[] args) {
        try {
            CommandLine commandLine = new CommandLine(this);
            int exitCode = commandLine.execute(args);
            System.exit(exitCode);
        } catch (Exception e) {
            logger.error("Error executing CLI command", e);
            System.exit(1);
        }
    }

    @Override
    public void run() {
        try {
            if (listPlugins) {
                listAvailablePlugins();
                return;
            }

            if (listTestTypes) {
                listSupportedTestTypes();
                return;
            }

            if (command == null) {
                System.out.println("No command specified. Use --help for usage information.");
                return;
            }

            switch (command.toLowerCase()) {
                case "run":
                    runTests();
                    break;
                case "discover":
                    discoverTests();
                    break;
                case "list":
                    listInformation();
                    break;
                default:
                    System.out.println("Unknown command: " + command);
                    System.out.println("Available commands: run, discover, list");
            }
        } catch (Exception e) {
            logger.error("Error executing CLI command", e);
            System.err.println("Error: " + e.getMessage());
        }
    }

    private void runTests() {
        System.out.println("Starting test execution...");
        
        // Create test configuration
        TestConfig config = createTestConfig();
        
        // Discover tests
        List<TestCase> testCases = discoverTestCases();
        
        if (testCases.isEmpty()) {
            System.out.println("No tests found to execute.");
            return;
        }

        // Filter by test type if specified
        if (testType != null) {
            testCases = testCases.stream()
                    .filter(tc -> testType.equalsIgnoreCase(tc.getType()))
                    .toList();
        }

        System.out.println("Found " + testCases.size() + " test(s) to execute.");

        // Execute tests
        try {
            CompletableFuture<TestRunResult> future = orchestrator.executeTests(testCases, config);
            TestRunResult result = future.get();

            // Display results
            displayResults(result);

        } catch (Exception e) {
            logger.error("Error executing tests", e);
            System.err.println("Test execution failed: " + e.getMessage());
        }
    }

    private void discoverTests() {
        System.out.println("Discovering tests...");
        
        List<TestCase> testCases = discoverTestCases();
        
        if (testCases.isEmpty()) {
            System.out.println("No tests found.");
            return;
        }

        System.out.println("Found " + testCases.size() + " test(s):");
        for (TestCase testCase : testCases) {
            System.out.printf("  - %s [%s] - %s%n", 
                    testCase.getName(), 
                    testCase.getType(), 
                    testCase.getDescription());
        }
    }

    private void listInformation() {
        listAvailablePlugins();
        System.out.println();
        listSupportedTestTypes();
    }

    private void listAvailablePlugins() {
        System.out.println("Available Plugins:");
        
        List<String> runnerPlugins = pluginManager.getAvailableRunnerPlugins();
        System.out.println("  Runner Plugins:");
        for (String plugin : runnerPlugins) {
            System.out.println("    - " + plugin);
        }

        List<String> reportingPlugins = pluginManager.getAvailableReportingPlugins();
        System.out.println("  Reporting Plugins:");
        for (String plugin : reportingPlugins) {
            System.out.println("    - " + plugin);
        }
    }

    private void listSupportedTestTypes() {
        System.out.println("Supported Test Types:");
        List<String> testTypes = pluginManager.getSupportedTestTypes();
        for (String type : testTypes) {
            System.out.println("  - " + type);
        }
    }

    private List<TestCase> discoverTestCases() {
        if (testFiles != null && !testFiles.isEmpty()) {
            return discoveryService.discoverTestsFromFiles(testFiles);
        } else if (testDirectory != null) {
            return discoveryService.discoverTestsFromDirectory(testDirectory);
        } else {
            // Default to current directory
            return discoveryService.discoverTestsFromDirectory(".");
        }
    }

    private TestConfig createTestConfig() {
        TestConfig config = new TestConfig();
        config.setEnvironment(environment);
        config.setParallel(parallel);
        config.setMaxConcurrency(maxConcurrency);
        config.setContinueOnFailure(continueOnFailure);
        config.setReportFormat(reportFormat);
        config.setReportOutputDir(reportDir);
        
        return config;
    }

    private void displayResults(TestRunResult result) {
        System.out.println("\n" + "=".repeat(50));
        System.out.println("TEST EXECUTION SUMMARY");
        System.out.println("=".repeat(50));
        
        System.out.printf("Execution ID: %s%n", result.getExecutionId());
        System.out.printf("Status: %s%n", result.getStatus());
        System.out.printf("Duration: %s%n", result.getFormattedDuration());
        System.out.printf("Total Tests: %d%n", result.getTotalTests());
        System.out.printf("Passed: %d%n", result.getPassedTests());
        System.out.printf("Failed: %d%n", result.getFailedTests());
        System.out.printf("Skipped: %d%n", result.getSkippedTests());
        System.out.printf("Success Rate: %.1f%%%n", result.getSuccessRate());
        
        if (result.getErrorMessage() != null) {
            System.out.println("Error: " + result.getErrorMessage());
        }
        
        System.out.println("=".repeat(50));
    }
}
