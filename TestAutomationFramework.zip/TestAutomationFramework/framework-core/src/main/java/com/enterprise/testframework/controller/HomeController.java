package com.enterprise.testframework.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.Map;

/**
 * Home page controller for the Test Framework
 */
@RestController
public class HomeController {

    /**
     * Welcome page
     */
    @GetMapping("/")
    public Map<String, Object> home() {
        Map<String, Object> response = new HashMap<>();
        response.put("name", "Enterprise Test Automation Framework");
        response.put("version", "1.0.0-SNAPSHOT");
        response.put("description", "A modular, plugin-based test automation framework for enterprise testing");
        response.put("status", "running");
        
        Map<String, String> endpoints = new HashMap<>();
        endpoints.put("plugins", "/api/tests/plugins");
        endpoints.put("execute", "/api/tests/execute (POST)");
        endpoints.put("health", "/actuator/health");
        
        response.put("endpoints", endpoints);
        return response;
    }

    /**
     * Framework information
     */
    @GetMapping("/info")
    public Map<String, Object> info() {
        Map<String, Object> response = new HashMap<>();
        response.put("framework", "Enterprise Test Automation Framework");
        response.put("capabilities", new String[]{
            "UI Testing (Selenium, Playwright)",
            "API Testing (RestAssured, Karate)",
            "Database Testing (JDBC, SQL)",
            "Performance Testing (JMeter, Gatling)",
            "ETL Testing (Data validation)",
            "Unified Reporting",
            "Parallel Execution",
            "Plugin-based Architecture"
        });
        response.put("architecture", "Spring Boot + Plugin System");
        response.put("buildVersion", "1.0.0-SNAPSHOT");
        return response;
    }
}