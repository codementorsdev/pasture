package com.enterprise.testframework.controller;

import com.enterprise.testframework.core.PluginManager;
import com.enterprise.testframework.core.TestDiscoveryService;
import com.enterprise.testframework.core.TestExecutionOrchestrator;
import com.enterprise.testframework.model.TestCase;
import com.enterprise.testframework.model.TestConfig;
import com.enterprise.testframework.model.TestRunResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * REST API controller for test execution
 */
@RestController
@RequestMapping("/api/tests")
public class TestExecutionController {

    @Autowired
    private TestExecutionOrchestrator orchestrator;

    @Autowired
    private TestDiscoveryService discoveryService;

    @Autowired
    private PluginManager pluginManager;

    /**
     * Execute tests
     */
    @PostMapping("/execute")
    public ResponseEntity<Map<String, String>> executeTests(@RequestBody ExecuteTestsRequest request) {
        try {
            TestConfig config = request.getConfig() != null ? request.getConfig() : new TestConfig();
            List<TestCase> testCases;

            if (request.getTestCases() != null && !request.getTestCases().isEmpty()) {
                testCases = request.getTestCases();
            } else if (request.getTestDirectory() != null) {
                testCases = discoveryService.discoverTestsFromDirectory(request.getTestDirectory());
            } else if (request.getTestFiles() != null && !request.getTestFiles().isEmpty()) {
                testCases = discoveryService.discoverTestsFromFiles(request.getTestFiles());
            } else {
                return ResponseEntity.badRequest().body(Map.of("error", "No test cases, directory, or files specified"));
            }

            if (testCases.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "No test cases found"));
            }

            // Filter by test type if specified
            if (request.getTestType() != null) {
                testCases = testCases.stream()
                        .filter(tc -> request.getTestType().equalsIgnoreCase(tc.getType()))
                        .toList();
            }

            CompletableFuture<TestRunResult> future = orchestrator.executeTests(testCases, config);
            TestRunResult result = future.get();

            return ResponseEntity.ok(Map.of(
                    "executionId", result.getExecutionId(),
                    "status", result.getStatus().name(),
                    "message", "Test execution completed"
            ));

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Get execution status
     */
    @GetMapping("/execution/{executionId}")
    public ResponseEntity<TestRunResult> getExecutionStatus(@PathVariable String executionId) {
        TestRunResult result = orchestrator.getExecutionStatus(executionId);
        if (result != null) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Get all active executions
     */
    @GetMapping("/executions")
    public ResponseEntity<Map<String, TestRunResult>> getActiveExecutions() {
        Map<String, TestRunResult> executions = orchestrator.getActiveExecutions();
        return ResponseEntity.ok(executions);
    }

    /**
     * Discover tests from directory
     */
    @PostMapping("/discover")
    public ResponseEntity<List<TestCase>> discoverTests(@RequestBody DiscoverTestsRequest request) {
        try {
            List<TestCase> testCases;

            if (request.getDirectory() != null) {
                testCases = discoveryService.discoverTestsFromDirectory(request.getDirectory());
            } else if (request.getFiles() != null && !request.getFiles().isEmpty()) {
                testCases = discoveryService.discoverTestsFromFiles(request.getFiles());
            } else {
                return ResponseEntity.badRequest().build();
            }

            return ResponseEntity.ok(testCases);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get available plugins
     */
    @GetMapping("/plugins")
    public ResponseEntity<Map<String, Object>> getPlugins() {
        Map<String, Object> plugins = Map.of(
                "runnerPlugins", pluginManager.getAvailableRunnerPlugins(),
                "reportingPlugins", pluginManager.getAvailableReportingPlugins(),
                "supportedTestTypes", pluginManager.getSupportedTestTypes()
        );
        return ResponseEntity.ok(plugins);
    }

    /**
     * Check if test type is supported
     */
    @GetMapping("/types/{testType}/supported")
    public ResponseEntity<Map<String, Boolean>> isTestTypeSupported(@PathVariable String testType) {
        boolean supported = pluginManager.isTestTypeSupported(testType);
        return ResponseEntity.ok(Map.of("supported", supported));
    }

    // Request DTOs
    public static class ExecuteTestsRequest {
        private List<TestCase> testCases;
        private String testDirectory;
        private List<String> testFiles;
        private String testType;
        private TestConfig config;

        // Getters and setters
        public List<TestCase> getTestCases() { return testCases; }
        public void setTestCases(List<TestCase> testCases) { this.testCases = testCases; }
        public String getTestDirectory() { return testDirectory; }
        public void setTestDirectory(String testDirectory) { this.testDirectory = testDirectory; }
        public List<String> getTestFiles() { return testFiles; }
        public void setTestFiles(List<String> testFiles) { this.testFiles = testFiles; }
        public String getTestType() { return testType; }
        public void setTestType(String testType) { this.testType = testType; }
        public TestConfig getConfig() { return config; }
        public void setConfig(TestConfig config) { this.config = config; }
    }

    public static class DiscoverTestsRequest {
        private String directory;
        private List<String> files;

        // Getters and setters
        public String getDirectory() { return directory; }
        public void setDirectory(String directory) { this.directory = directory; }
        public List<String> getFiles() { return files; }
        public void setFiles(List<String> files) { this.files = files; }
    }
}
