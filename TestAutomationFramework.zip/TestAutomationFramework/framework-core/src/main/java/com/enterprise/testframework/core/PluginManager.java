package com.enterprise.testframework.core;

import com.enterprise.testframework.interfaces.IRunnerPlugin;
import com.enterprise.testframework.interfaces.IReportingPlugin;
import com.enterprise.testframework.interfaces.ITestTypeClassifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.plugin.core.PluginRegistry;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Plugin manager for lifecycle management and discovery
 */
@Component
public class PluginManager {

    private static final Logger logger = LoggerFactory.getLogger(PluginManager.class);

    @Autowired
    private PluginRegistry<IRunnerPlugin, String> runnerPluginRegistry;

    @Autowired
    private PluginRegistry<IReportingPlugin, String> reportingPluginRegistry;

    @Autowired
    private PluginRegistry<ITestTypeClassifier, String> classifierPluginRegistry;

    /**
     * Initialize plugin manager and discover available plugins
     */
    @PostConstruct
    public void initialize() {
        logger.info("Initializing Plugin Manager");
        discoverPlugins();
    }

    /**
     * Discover and log available plugins
     */
    private void discoverPlugins() {
        logger.info("Discovering plugins...");

        // Runner plugins
        List<IRunnerPlugin> runnerPlugins = runnerPluginRegistry.getPlugins();
        logger.info("Found {} runner plugins:", runnerPlugins.size());
        runnerPlugins.forEach(plugin -> {
            logger.info("  - {}: {}", plugin.getClass().getSimpleName(), plugin.getPluginName());
        });

        // Reporting plugins
        List<IReportingPlugin> reportingPlugins = reportingPluginRegistry.getPlugins();
        logger.info("Found {} reporting plugins:", reportingPlugins.size());
        reportingPlugins.forEach(plugin -> {
            logger.info("  - {}: {}", plugin.getClass().getSimpleName(), plugin.getPluginName());
        });

        // Classifier plugins
        List<ITestTypeClassifier> classifierPlugins = classifierPluginRegistry.getPlugins();
        logger.info("Found {} classifier plugins:", classifierPlugins.size());
        classifierPlugins.forEach(plugin -> {
            logger.info("  - {}: {}", plugin.getClass().getSimpleName(), plugin.getPluginName());
        });
    }

    /**
     * Get available runner plugins
     */
    public List<String> getAvailableRunnerPlugins() {
        return runnerPluginRegistry.getPlugins().stream()
            .map(IRunnerPlugin::getPluginName)
            .collect(Collectors.toList());
    }

    /**
     * Get available reporting plugins
     */
    public List<String> getAvailableReportingPlugins() {
        return reportingPluginRegistry.getPlugins().stream()
            .map(IReportingPlugin::getPluginName)
            .collect(Collectors.toList());
    }

    /**
     * Get supported test types
     */
    public List<String> getSupportedTestTypes() {
        return runnerPluginRegistry.getPlugins().stream()
            .flatMap(plugin -> plugin.getSupportedTestTypes().stream())
            .distinct()
            .collect(Collectors.toList());
    }

    /**
     * Get runner plugin for specific test type
     */
    public IRunnerPlugin getRunnerPlugin(String testType) {
        return runnerPluginRegistry.getPluginFor(testType).orElse(null);
    }

    /**
     * Check if test type is supported
     */
    public boolean isTestTypeSupported(String testType) {
        return runnerPluginRegistry.getPluginFor(testType).isPresent();
    }
}
