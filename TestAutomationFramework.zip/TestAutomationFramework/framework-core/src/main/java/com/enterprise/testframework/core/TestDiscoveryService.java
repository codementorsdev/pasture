package com.enterprise.testframework.core;

import com.enterprise.testframework.model.TestCase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Service for discovering test cases from various sources
 */
@Service
public class TestDiscoveryService {

    private static final Logger logger = LoggerFactory.getLogger(TestDiscoveryService.class);

    /**
     * Discover test cases from a directory
     */
    public List<TestCase> discoverTestsFromDirectory(String directoryPath) {
        List<TestCase> testCases = new ArrayList<>();
        
        try {
            Path dir = Paths.get(directoryPath);
            if (!Files.exists(dir) || !Files.isDirectory(dir)) {
                logger.warn("Directory does not exist or is not a directory: {}", directoryPath);
                return testCases;
            }

            try (Stream<Path> paths = Files.walk(dir)) {
                paths.filter(Files::isRegularFile)
                     .filter(this::isTestFile)
                     .forEach(path -> {
                         TestCase testCase = createTestCaseFromFile(path);
                         if (testCase != null) {
                             testCases.add(testCase);
                         }
                     });
            }
        } catch (IOException e) {
            logger.error("Error discovering tests from directory: {}", directoryPath, e);
        }

        logger.info("Discovered {} test cases from directory: {}", testCases.size(), directoryPath);
        return testCases;
    }

    /**
     * Discover test cases from a list of file paths
     */
    public List<TestCase> discoverTestsFromFiles(List<String> filePaths) {
        List<TestCase> testCases = new ArrayList<>();

        for (String filePath : filePaths) {
            Path path = Paths.get(filePath);
            if (Files.exists(path) && Files.isRegularFile(path)) {
                TestCase testCase = createTestCaseFromFile(path);
                if (testCase != null) {
                    testCases.add(testCase);
                }
            } else {
                logger.warn("File does not exist: {}", filePath);
            }
        }

        logger.info("Discovered {} test cases from file list", testCases.size());
        return testCases;
    }

    /**
     * Create test case from programmatic definition
     */
    public TestCase createTestCase(String name, String type, String description, Map<String, Object> properties) {
        TestCase testCase = new TestCase();
        testCase.setName(name);
        testCase.setType(type);
        testCase.setDescription(description);
        testCase.setProperties(properties != null ? properties : new HashMap<>());
        
        return testCase;
    }

    /**
     * Check if file is a test file based on naming conventions
     */
    private boolean isTestFile(Path path) {
        String fileName = path.getFileName().toString().toLowerCase();
        return fileName.contains("test") || 
               fileName.endsWith(".test.java") ||
               fileName.endsWith(".spec.java") ||
               fileName.endsWith(".feature") ||
               fileName.endsWith(".json") ||
               fileName.endsWith(".xml") ||
               fileName.endsWith(".yaml") ||
               fileName.endsWith(".yml");
    }

    /**
     * Create test case from file
     */
    private TestCase createTestCaseFromFile(Path filePath) {
        try {
            String fileName = filePath.getFileName().toString();
            String fileExtension = getFileExtension(fileName);
            
            TestCase testCase = new TestCase();
            testCase.setName(fileName);
            testCase.setFilePath(filePath.toString());
            testCase.setType(determineTestType(fileExtension, fileName));
            testCase.setDescription("Test case from file: " + fileName);
            
            // Add file-specific properties
            Map<String, Object> properties = new HashMap<>();
            properties.put("file.path", filePath.toString());
            properties.put("file.name", fileName);
            properties.put("file.extension", fileExtension);
            properties.put("file.size", Files.size(filePath));
            testCase.setProperties(properties);

            return testCase;
        } catch (IOException e) {
            logger.error("Error creating test case from file: {}", filePath, e);
            return null;
        }
    }

    /**
     * Get file extension
     */
    private String getFileExtension(String fileName) {
        int lastDotIndex = fileName.lastIndexOf('.');
        return lastDotIndex != -1 ? fileName.substring(lastDotIndex + 1) : "";
    }

    /**
     * Determine test type based on file extension and name
     */
    private String determineTestType(String extension, String fileName) {
        String lowerFileName = fileName.toLowerCase();
        
        if (lowerFileName.contains("ui") || lowerFileName.contains("selenium") || lowerFileName.contains("web")) {
            return "ui";
        } else if (lowerFileName.contains("api") || lowerFileName.contains("rest") || lowerFileName.contains("http")) {
            return "api";
        } else if (lowerFileName.contains("db") || lowerFileName.contains("database") || lowerFileName.contains("sql")) {
            return "database";
        } else if (lowerFileName.contains("perf") || lowerFileName.contains("performance") || lowerFileName.contains("load")) {
            return "performance";
        } else if (lowerFileName.contains("etl") || lowerFileName.contains("data")) {
            return "etl";
        }
        
        // Default based on extension
        switch (extension.toLowerCase()) {
            case "java":
                return "unit";
            case "feature":
                return "bdd";
            case "json":
            case "xml":
            case "yaml":
            case "yml":
                return "api";
            default:
                return "unknown";
        }
    }
}
