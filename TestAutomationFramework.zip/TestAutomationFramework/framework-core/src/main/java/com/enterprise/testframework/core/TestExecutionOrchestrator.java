package com.enterprise.testframework.core;

import com.enterprise.testframework.interfaces.IRunnerPlugin;
import com.enterprise.testframework.interfaces.ITestTypeClassifier;
import com.enterprise.testframework.model.TestCase;
import com.enterprise.testframework.model.TestConfig;
import com.enterprise.testframework.model.TestRunResult;
import com.enterprise.testframework.model.TestStatus;
import com.enterprise.testframework.reporting.UnifiedReportingEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.plugin.core.PluginRegistry;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

/**
 * Central orchestrator for test execution
 * Handles intelligent routing and parallel execution
 */
@Component
public class TestExecutionOrchestrator {

    private static final Logger logger = LoggerFactory.getLogger(TestExecutionOrchestrator.class);

    @Autowired
    private PluginRegistry<IRunnerPlugin, String> runnerPluginRegistry;

    @Autowired
    private PluginRegistry<ITestTypeClassifier, String> classifierPluginRegistry;

    @Autowired
    private UnifiedReportingEngine reportingEngine;

    @Autowired
    @Qualifier("testExecutor")
    private Executor testExecutor;

    private final Map<String, TestRunResult> activeExecutions = new ConcurrentHashMap<>();

    /**
     * Execute tests with intelligent routing based on test type
     */
    public CompletableFuture<TestRunResult> executeTests(List<TestCase> testCases, TestConfig config) {
        String executionId = generateExecutionId();
        logger.info("Starting test execution with ID: {}", executionId);

        return CompletableFuture.supplyAsync(() -> {
            TestRunResult overallResult = new TestRunResult();
            overallResult.setExecutionId(executionId);
            overallResult.setStartTime(LocalDateTime.now());
            overallResult.setStatus(TestStatus.RUNNING);

            activeExecutions.put(executionId, overallResult);

            try {
                // Group tests by type
                Map<String, List<TestCase>> testsByType = groupTestsByType(testCases);

                // Execute tests in parallel by type
                List<CompletableFuture<TestRunResult>> futures = testsByType.entrySet().stream()
                    .map(entry -> executeTestsForType(entry.getKey(), entry.getValue(), config))
                    .collect(Collectors.toList());

                // Wait for all executions to complete
                CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

                // Aggregate results
                aggregateResults(overallResult, futures);

                overallResult.setEndTime(LocalDateTime.now());
                overallResult.setStatus(TestStatus.COMPLETED);

                // Generate reports
                reportingEngine.generateReports(overallResult);

            } catch (Exception e) {
                logger.error("Test execution failed", e);
                overallResult.setStatus(TestStatus.FAILED);
                overallResult.setErrorMessage(e.getMessage());
                overallResult.setEndTime(LocalDateTime.now());
            } finally {
                activeExecutions.remove(executionId);
            }

            return overallResult;
        }, testExecutor);
    }

    /**
     * Execute tests for a specific type
     */
    @Async("testExecutor")
    private CompletableFuture<TestRunResult> executeTestsForType(String testType, List<TestCase> testCases, TestConfig config) {
        return CompletableFuture.supplyAsync(() -> {
            logger.info("Executing {} tests of type: {}", testCases.size(), testType);

            // Find appropriate runner plugin
            IRunnerPlugin runner = runnerPluginRegistry.getPluginFor(testType).orElse(null);
            if (runner == null) {
                logger.error("No runner plugin found for test type: {}", testType);
                TestRunResult result = new TestRunResult();
                result.setStatus(TestStatus.FAILED);
                result.setErrorMessage("No runner plugin found for test type: " + testType);
                return result;
            }

            // Execute tests using the plugin
            return runner.runTests(testCases, config);
        }, testExecutor);
    }

    /**
     * Group tests by their type using classifiers
     */
    private Map<String, List<TestCase>> groupTestsByType(List<TestCase> testCases) {
        return testCases.stream()
            .collect(Collectors.groupingBy(this::classifyTestType));
    }

    /**
     * Classify test type using available classifiers
     */
    private String classifyTestType(TestCase testCase) {
        for (ITestTypeClassifier classifier : classifierPluginRegistry.getPlugins()) {
            String type = classifier.classifyTest(testCase);
            if (type != null) {
                return type;
            }
        }
        return "unknown";
    }

    /**
     * Aggregate results from multiple test type executions
     */
    private void aggregateResults(TestRunResult overallResult, List<CompletableFuture<TestRunResult>> futures) {
        int totalTests = 0;
        int passedTests = 0;
        int failedTests = 0;
        boolean hasFailures = false;

        for (CompletableFuture<TestRunResult> future : futures) {
            try {
                TestRunResult result = future.get();
                totalTests += result.getTotalTests();
                passedTests += result.getPassedTests();
                failedTests += result.getFailedTests();
                
                if (result.getStatus() == TestStatus.FAILED) {
                    hasFailures = true;
                }
            } catch (Exception e) {
                logger.error("Error aggregating test results", e);
                hasFailures = true;
            }
        }

        overallResult.setTotalTests(totalTests);
        overallResult.setPassedTests(passedTests);
        overallResult.setFailedTests(failedTests);
        overallResult.setStatus(hasFailures ? TestStatus.FAILED : TestStatus.PASSED);
    }

    /**
     * Get status of active execution
     */
    public TestRunResult getExecutionStatus(String executionId) {
        return activeExecutions.get(executionId);
    }

    /**
     * List all active executions
     */
    public Map<String, TestRunResult> getActiveExecutions() {
        return new ConcurrentHashMap<>(activeExecutions);
    }

    /**
     * Generate unique execution ID
     */
    private String generateExecutionId() {
        return "exec-" + System.currentTimeMillis() + "-" + Thread.currentThread().getId();
    }
}
