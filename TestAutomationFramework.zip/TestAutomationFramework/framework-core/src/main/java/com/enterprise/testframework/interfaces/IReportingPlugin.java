package com.enterprise.testframework.interfaces;

import com.enterprise.testframework.model.TestRunResult;
import org.springframework.plugin.core.Plugin;

/**
 * Interface for reporting plugins
 * Handles generation of test reports in various formats
 */
public interface IReportingPlugin extends Plugin<String> {

    /**
     * Get plugin name
     */
    String getPluginName();

    /**
     * Generate report for test results
     */
    void generateReport(TestRunResult testResult);

    /**
     * Get supported report formats
     */
    String[] getSupportedFormats();

    /**
     * Get report output location
     */
    String getReportOutputLocation();

    /**
     * Finalize reporting process
     */
    default void finalizeReporting() {
        // Default implementation - no action needed
    }

    /**
     * Get plugin version
     */
    default String getVersion() {
        return "1.0.0";
    }

    /**
     * Get plugin description
     */
    default String getDescription() {
        return "Reporting plugin";
    }

    /**
     * Check if plugin supports specific format
     */
    default boolean supportsFormat(String format) {
        String[] supportedFormats = getSupportedFormats();
        for (String supportedFormat : supportedFormats) {
            if (supportedFormat.equalsIgnoreCase(format)) {
                return true;
            }
        }
        return false;
    }
}
