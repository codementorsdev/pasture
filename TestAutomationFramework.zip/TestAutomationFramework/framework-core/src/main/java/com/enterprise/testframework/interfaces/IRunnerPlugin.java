package com.enterprise.testframework.interfaces;

import com.enterprise.testframework.model.TestCase;
import com.enterprise.testframework.model.TestConfig;
import com.enterprise.testframework.model.TestRunResult;
import org.springframework.plugin.core.Plugin;

import java.util.List;

/**
 * Interface for test runner plugins
 * Each plugin implements execution logic for specific test types
 */
public interface IRunnerPlugin extends Plugin<String> {

    /**
     * Get plugin name
     */
    String getPluginName();

    /**
     * Get supported test types
     */
    List<String> getSupportedTestTypes();

    /**
     * Check if plugin supports specific test type
     */
    boolean supportsTestType(String testType);

    /**
     * Run tests using this plugin
     */
    TestRunResult runTests(List<TestCase> testCases, TestConfig config);

    /**
     * Get plugin configuration schema
     */
    default String getConfigurationSchema() {
        return "{}";
    }

    /**
     * Validate plugin configuration
     */
    default boolean validateConfiguration(TestConfig config) {
        return true;
    }

    /**
     * Get plugin version
     */
    default String getVersion() {
        return "1.0.0";
    }

    /**
     * Get plugin description
     */
    default String getDescription() {
        return "Test runner plugin";
    }
}
