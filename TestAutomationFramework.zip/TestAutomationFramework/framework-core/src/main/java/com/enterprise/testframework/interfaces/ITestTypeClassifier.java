package com.enterprise.testframework.interfaces;

import com.enterprise.testframework.model.TestCase;
import org.springframework.plugin.core.Plugin;

/**
 * Interface for test type classification plugins
 * Determines test type based on test case properties
 */
public interface ITestTypeClassifier extends Plugin<String> {

    /**
     * Get plugin name
     */
    String getPluginName();

    /**
     * Classify test case and return test type
     */
    String classifyTest(TestCase testCase);

    /**
     * Get classification confidence (0.0 to 1.0)
     */
    double getClassificationConfidence(TestCase testCase);

    /**
     * Get supported test types this classifier can detect
     */
    String[] getSupportedTestTypes();

    /**
     * Get classification priority (higher priority classifiers are checked first)
     */
    default int getPriority() {
        return 0;
    }

    /**
     * Get plugin version
     */
    default String getVersion() {
        return "1.0.0";
    }

    /**
     * Get plugin description
     */
    default String getDescription() {
        return "Test type classifier plugin";
    }
}
