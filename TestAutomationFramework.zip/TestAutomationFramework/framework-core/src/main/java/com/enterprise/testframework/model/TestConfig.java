package com.enterprise.testframework.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuration model for test execution
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TestConfig {

    private String environment = "test";
    private boolean parallel = true;
    private int maxConcurrency = 4;
    private long defaultTimeoutMillis = 30000;
    private boolean continueOnFailure = false;
    private String reportFormat = "json";
    private String reportOutputDir = "./reports";
    private Map<String, Object> properties = new HashMap<>();
    private Map<String, Object> environmentVariables = new HashMap<>();

    // Browser configuration for UI tests
    private String browser = "chrome";
    private boolean headless = false;
    private String browserVersion = "latest";

    // API configuration
    private String baseUrl;
    private Map<String, String> headers = new HashMap<>();
    private int apiTimeoutMillis = 10000;

    // Database configuration
    private String dbUrl;
    private String dbUsername;
    private String dbPassword;
    private String dbDriver;

    // Performance test configuration
    private int virtualUsers = 10;
    private int rampUpTimeSeconds = 60;
    private int testDurationSeconds = 300;

    // Constructors
    public TestConfig() {}

    public TestConfig(String environment) {
        this.environment = environment;
    }

    // Getters and Setters
    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public boolean isParallel() {
        return parallel;
    }

    public void setParallel(boolean parallel) {
        this.parallel = parallel;
    }

    public int getMaxConcurrency() {
        return maxConcurrency;
    }

    public void setMaxConcurrency(int maxConcurrency) {
        this.maxConcurrency = maxConcurrency;
    }

    public long getDefaultTimeoutMillis() {
        return defaultTimeoutMillis;
    }

    public void setDefaultTimeoutMillis(long defaultTimeoutMillis) {
        this.defaultTimeoutMillis = defaultTimeoutMillis;
    }

    public boolean isContinueOnFailure() {
        return continueOnFailure;
    }

    public void setContinueOnFailure(boolean continueOnFailure) {
        this.continueOnFailure = continueOnFailure;
    }

    public String getReportFormat() {
        return reportFormat;
    }

    public void setReportFormat(String reportFormat) {
        this.reportFormat = reportFormat;
    }

    public String getReportOutputDir() {
        return reportOutputDir;
    }

    public void setReportOutputDir(String reportOutputDir) {
        this.reportOutputDir = reportOutputDir;
    }

    public Map<String, Object> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, Object> properties) {
        this.properties = properties;
    }

    public Map<String, Object> getEnvironmentVariables() {
        return environmentVariables;
    }

    public void setEnvironmentVariables(Map<String, Object> environmentVariables) {
        this.environmentVariables = environmentVariables;
    }

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(String browser) {
        this.browser = browser;
    }

    public boolean isHeadless() {
        return headless;
    }

    public void setHeadless(boolean headless) {
        this.headless = headless;
    }

    public String getBrowserVersion() {
        return browserVersion;
    }

    public void setBrowserVersion(String browserVersion) {
        this.browserVersion = browserVersion;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public int getApiTimeoutMillis() {
        return apiTimeoutMillis;
    }

    public void setApiTimeoutMillis(int apiTimeoutMillis) {
        this.apiTimeoutMillis = apiTimeoutMillis;
    }

    public String getDbUrl() {
        return dbUrl;
    }

    public void setDbUrl(String dbUrl) {
        this.dbUrl = dbUrl;
    }

    public String getDbUsername() {
        return dbUsername;
    }

    public void setDbUsername(String dbUsername) {
        this.dbUsername = dbUsername;
    }

    public String getDbPassword() {
        return dbPassword;
    }

    public void setDbPassword(String dbPassword) {
        this.dbPassword = dbPassword;
    }

    public String getDbDriver() {
        return dbDriver;
    }

    public void setDbDriver(String dbDriver) {
        this.dbDriver = dbDriver;
    }

    public int getVirtualUsers() {
        return virtualUsers;
    }

    public void setVirtualUsers(int virtualUsers) {
        this.virtualUsers = virtualUsers;
    }

    public int getRampUpTimeSeconds() {
        return rampUpTimeSeconds;
    }

    public void setRampUpTimeSeconds(int rampUpTimeSeconds) {
        this.rampUpTimeSeconds = rampUpTimeSeconds;
    }

    public int getTestDurationSeconds() {
        return testDurationSeconds;
    }

    public void setTestDurationSeconds(int testDurationSeconds) {
        this.testDurationSeconds = testDurationSeconds;
    }

    // Utility methods
    public void addProperty(String key, Object value) {
        if (properties == null) {
            properties = new HashMap<>();
        }
        properties.put(key, value);
    }

    public Object getProperty(String key) {
        return properties != null ? properties.get(key) : null;
    }

    public String getPropertyAsString(String key) {
        Object value = getProperty(key);
        return value != null ? value.toString() : null;
    }

    public void addEnvironmentVariable(String key, Object value) {
        if (environmentVariables == null) {
            environmentVariables = new HashMap<>();
        }
        environmentVariables.put(key, value);
    }

    public void addHeader(String key, String value) {
        if (headers == null) {
            headers = new HashMap<>();
        }
        headers.put(key, value);
    }
}
