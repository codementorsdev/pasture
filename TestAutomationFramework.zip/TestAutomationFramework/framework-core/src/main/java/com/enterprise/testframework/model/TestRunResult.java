package com.enterprise.testframework.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Model representing test execution results
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TestRunResult {

    private String executionId;
    private String testSuiteName;
    private TestStatus status;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private long durationMillis;
    
    private int totalTests;
    private int passedTests;
    private int failedTests;
    private int skippedTests;
    
    private List<TestCaseResult> testResults = new ArrayList<>();
    private Map<String, Object> metadata = new HashMap<>();
    private String errorMessage;
    private List<String> warnings = new ArrayList<>();
    
    // Environment and configuration info
    private String environment;
    private String testType;
    private String executedBy;
    private String pluginUsed;

    // Constructors
    public TestRunResult() {}

    public TestRunResult(String executionId) {
        this.executionId = executionId;
        this.status = TestStatus.RUNNING;
        this.startTime = LocalDateTime.now();
    }

    // Getters and Setters
    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public String getTestSuiteName() {
        return testSuiteName;
    }

    public void setTestSuiteName(String testSuiteName) {
        this.testSuiteName = testSuiteName;
    }

    public TestStatus getStatus() {
        return status;
    }

    public void setStatus(TestStatus status) {
        this.status = status;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
        if (startTime != null && endTime != null) {
            this.durationMillis = java.time.Duration.between(startTime, endTime).toMillis();
        }
    }

    public long getDurationMillis() {
        return durationMillis;
    }

    public void setDurationMillis(long durationMillis) {
        this.durationMillis = durationMillis;
    }

    public int getTotalTests() {
        return totalTests;
    }

    public void setTotalTests(int totalTests) {
        this.totalTests = totalTests;
    }

    public int getPassedTests() {
        return passedTests;
    }

    public void setPassedTests(int passedTests) {
        this.passedTests = passedTests;
    }

    public int getFailedTests() {
        return failedTests;
    }

    public void setFailedTests(int failedTests) {
        this.failedTests = failedTests;
    }

    public int getSkippedTests() {
        return skippedTests;
    }

    public void setSkippedTests(int skippedTests) {
        this.skippedTests = skippedTests;
    }

    public List<TestCaseResult> getTestResults() {
        return testResults;
    }

    public void setTestResults(List<TestCaseResult> testResults) {
        this.testResults = testResults;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public List<String> getWarnings() {
        return warnings;
    }

    public void setWarnings(List<String> warnings) {
        this.warnings = warnings;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getTestType() {
        return testType;
    }

    public void setTestType(String testType) {
        this.testType = testType;
    }

    public String getExecutedBy() {
        return executedBy;
    }

    public void setExecutedBy(String executedBy) {
        this.executedBy = executedBy;
    }

    public String getPluginUsed() {
        return pluginUsed;
    }

    public void setPluginUsed(String pluginUsed) {
        this.pluginUsed = pluginUsed;
    }

    // Utility methods
    public void addTestResult(TestCaseResult testResult) {
        if (testResults == null) {
            testResults = new ArrayList<>();
        }
        testResults.add(testResult);
    }

    public void addMetadata(String key, Object value) {
        if (metadata == null) {
            metadata = new HashMap<>();
        }
        metadata.put(key, value);
    }

    public void addWarning(String warning) {
        if (warnings == null) {
            warnings = new ArrayList<>();
        }
        warnings.add(warning);
    }

    public double getSuccessRate() {
        if (totalTests == 0) {
            return 0.0;
        }
        return (double) passedTests / totalTests * 100.0;
    }

    public String getFormattedDuration() {
        if (durationMillis < 1000) {
            return durationMillis + "ms";
        } else if (durationMillis < 60000) {
            return String.format("%.2fs", durationMillis / 1000.0);
        } else {
            long minutes = durationMillis / 60000;
            long seconds = (durationMillis % 60000) / 1000;
            return String.format("%dm %ds", minutes, seconds);
        }
    }

    /**
     * Inner class representing individual test case result
     */
    public static class TestCaseResult {
        private String testCaseName;
        private String testCaseId;
        private TestStatus status;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private long durationMillis;
        private String errorMessage;
        private String stackTrace;
        private Map<String, Object> attributes = new HashMap<>();

        // Constructors
        public TestCaseResult() {}

        public TestCaseResult(String testCaseName, TestStatus status) {
            this.testCaseName = testCaseName;
            this.status = status;
        }

        // Getters and Setters
        public String getTestCaseName() {
            return testCaseName;
        }

        public void setTestCaseName(String testCaseName) {
            this.testCaseName = testCaseName;
        }

        public String getTestCaseId() {
            return testCaseId;
        }

        public void setTestCaseId(String testCaseId) {
            this.testCaseId = testCaseId;
        }

        public TestStatus getStatus() {
            return status;
        }

        public void setStatus(TestStatus status) {
            this.status = status;
        }

        public LocalDateTime getStartTime() {
            return startTime;
        }

        public void setStartTime(LocalDateTime startTime) {
            this.startTime = startTime;
        }

        public LocalDateTime getEndTime() {
            return endTime;
        }

        public void setEndTime(LocalDateTime endTime) {
            this.endTime = endTime;
            if (startTime != null && endTime != null) {
                this.durationMillis = java.time.Duration.between(startTime, endTime).toMillis();
            }
        }

        public long getDurationMillis() {
            return durationMillis;
        }

        public void setDurationMillis(long durationMillis) {
            this.durationMillis = durationMillis;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }

        public String getStackTrace() {
            return stackTrace;
        }

        public void setStackTrace(String stackTrace) {
            this.stackTrace = stackTrace;
        }

        public Map<String, Object> getAttributes() {
            return attributes;
        }

        public void setAttributes(Map<String, Object> attributes) {
            this.attributes = attributes;
        }

        public void addAttribute(String key, Object value) {
            if (attributes == null) {
                attributes = new HashMap<>();
            }
            attributes.put(key, value);
        }
    }
}
