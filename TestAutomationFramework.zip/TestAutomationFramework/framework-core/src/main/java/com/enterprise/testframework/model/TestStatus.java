package com.enterprise.testframework.model;

/**
 * Enumeration for test execution status
 */
public enum TestStatus {
    PENDING("Test is pending execution"),
    RUNNING("Test is currently running"),
    PASSED("Test passed successfully"),
    FAILED("Test failed"),
    SKIPPED("Test was skipped"),
    COMPLETED("Test execution completed"),
    ABORTED("Test execution was aborted"),
    TIMEOUT("Test execution timed out");

    private final String description;

    TestStatus(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCompleted() {
        return this == PASSED || this == FAILED || this == SKIPPED || this == COMPLETED || this == ABORTED || this == TIMEOUT;
    }

    public boolean isSuccessful() {
        return this == PASSED || this == COMPLETED;
    }

    public boolean isFailure() {
        return this == FAILED || this == ABORTED || this == TIMEOUT;
    }
}
