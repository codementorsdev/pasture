package com.enterprise.testframework.reporting;

import com.enterprise.testframework.model.TestRunResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * File-based reporter that generates JSON, XML, and HTML reports
 */
@Component
public class FileBasedReporter {

    private static final Logger logger = LoggerFactory.getLogger(FileBasedReporter.class);
    private static final DateTimeFormatter TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");

    private final ObjectMapper jsonMapper;
    private final XmlMapper xmlMapper;

    public FileBasedReporter() {
        this.jsonMapper = new ObjectMapper();
        this.jsonMapper.registerModule(new JavaTimeModule());
        this.jsonMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        this.jsonMapper.configure(SerializationFeature.INDENT_OUTPUT, true);

        this.xmlMapper = new XmlMapper();
        this.xmlMapper.registerModule(new JavaTimeModule());
        this.xmlMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        this.xmlMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
    }

    /**
     * Generate all supported report formats
     */
    public void generateReport(TestRunResult testResult) {
        try {
            String reportDir = createReportDirectory(testResult);
            
            generateJsonReport(testResult, reportDir);
            generateXmlReport(testResult, reportDir);
            generateHtmlReport(testResult, reportDir);
            
            logger.info("Reports generated successfully in directory: {}", reportDir);
            
        } catch (Exception e) {
            logger.error("Error generating file-based reports: {}", e.getMessage(), e);
        }
    }

    /**
     * Create report directory
     */
    private String createReportDirectory(TestRunResult testResult) throws IOException {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMAT);
        String dirName = String.format("test-report-%s-%s", testResult.getExecutionId(), timestamp);
        Path reportPath = Paths.get("reports", dirName);
        
        Files.createDirectories(reportPath);
        return reportPath.toString();
    }

    /**
     * Generate JSON report
     */
    private void generateJsonReport(TestRunResult testResult, String reportDir) {
        try {
            String fileName = String.format("%s/test-results.json", reportDir);
            jsonMapper.writeValue(new File(fileName), testResult);
            logger.debug("JSON report generated: {}", fileName);
        } catch (Exception e) {
            logger.error("Error generating JSON report: {}", e.getMessage(), e);
        }
    }

    /**
     * Generate XML report
     */
    private void generateXmlReport(TestRunResult testResult, String reportDir) {
        try {
            String fileName = String.format("%s/test-results.xml", reportDir);
            xmlMapper.writeValue(new File(fileName), testResult);
            logger.debug("XML report generated: {}", fileName);
        } catch (Exception e) {
            logger.error("Error generating XML report: {}", e.getMessage(), e);
        }
    }

    /**
     * Generate HTML report
     */
    private void generateHtmlReport(TestRunResult testResult, String reportDir) {
        try {
            String fileName = String.format("%s/test-results.html", reportDir);
            String htmlContent = generateHtmlContent(testResult);
            
            try (FileWriter writer = new FileWriter(fileName)) {
                writer.write(htmlContent);
            }
            
            logger.debug("HTML report generated: {}", fileName);
        } catch (Exception e) {
            logger.error("Error generating HTML report: {}", e.getMessage(), e);
        }
    }

    /**
     * Generate HTML content for the report
     */
    private String generateHtmlContent(TestRunResult testResult) {
        StringBuilder html = new StringBuilder();
        
        html.append("<!DOCTYPE html>\n")
            .append("<html>\n")
            .append("<head>\n")
            .append("    <title>Test Execution Report</title>\n")
            .append("    <style>\n")
            .append("        body { font-family: Arial, sans-serif; margin: 20px; }\n")
            .append("        .header { background-color: #f4f4f4; padding: 20px; border-radius: 5px; }\n")
            .append("        .summary { display: flex; justify-content: space-around; margin: 20px 0; }\n")
            .append("        .summary-item { text-align: center; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }\n")
            .append("        .passed { background-color: #d4edda; color: #155724; }\n")
            .append("        .failed { background-color: #f8d7da; color: #721c24; }\n")
            .append("        .skipped { background-color: #fff3cd; color: #856404; }\n")
            .append("        .test-results { margin-top: 20px; }\n")
            .append("        .test-case { margin: 10px 0; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }\n")
            .append("        .test-case.passed { border-left: 4px solid #28a745; }\n")
            .append("        .test-case.failed { border-left: 4px solid #dc3545; }\n")
            .append("        .test-case.skipped { border-left: 4px solid #ffc107; }\n")
            .append("        .error-details { background-color: #f8f9fa; padding: 10px; margin-top: 10px; border-radius: 3px; }\n")
            .append("    </style>\n")
            .append("</head>\n")
            .append("<body>\n");

        // Header
        html.append("    <div class=\"header\">\n")
            .append("        <h1>Test Execution Report</h1>\n")
            .append("        <p><strong>Execution ID:</strong> ").append(testResult.getExecutionId()).append("</p>\n")
            .append("        <p><strong>Start Time:</strong> ").append(testResult.getStartTime()).append("</p>\n")
            .append("        <p><strong>End Time:</strong> ").append(testResult.getEndTime()).append("</p>\n")
            .append("        <p><strong>Duration:</strong> ").append(testResult.getFormattedDuration()).append("</p>\n")
            .append("        <p><strong>Status:</strong> ").append(testResult.getStatus()).append("</p>\n")
            .append("    </div>\n");

        // Summary
        html.append("    <div class=\"summary\">\n")
            .append("        <div class=\"summary-item\">\n")
            .append("            <h3>").append(testResult.getTotalTests()).append("</h3>\n")
            .append("            <p>Total Tests</p>\n")
            .append("        </div>\n")
            .append("        <div class=\"summary-item passed\">\n")
            .append("            <h3>").append(testResult.getPassedTests()).append("</h3>\n")
            .append("            <p>Passed</p>\n")
            .append("        </div>\n")
            .append("        <div class=\"summary-item failed\">\n")
            .append("            <h3>").append(testResult.getFailedTests()).append("</h3>\n")
            .append("            <p>Failed</p>\n")
            .append("        </div>\n")
            .append("        <div class=\"summary-item skipped\">\n")
            .append("            <h3>").append(testResult.getSkippedTests()).append("</h3>\n")
            .append("            <p>Skipped</p>\n")
            .append("        </div>\n")
            .append("        <div class=\"summary-item\">\n")
            .append("            <h3>").append(String.format("%.1f%%", testResult.getSuccessRate())).append("</h3>\n")
            .append("            <p>Success Rate</p>\n")
            .append("        </div>\n")
            .append("    </div>\n");

        // Test Results
        if (testResult.getTestResults() != null && !testResult.getTestResults().isEmpty()) {
            html.append("    <div class=\"test-results\">\n")
                .append("        <h2>Test Results</h2>\n");

            for (TestRunResult.TestCaseResult testCase : testResult.getTestResults()) {
                String statusClass = testCase.getStatus().name().toLowerCase();
                html.append("        <div class=\"test-case ").append(statusClass).append("\">\n")
                    .append("            <h4>").append(testCase.getTestCaseName()).append("</h4>\n")
                    .append("            <p><strong>Status:</strong> ").append(testCase.getStatus()).append("</p>\n")
                    .append("            <p><strong>Duration:</strong> ").append(testCase.getDurationMillis()).append("ms</p>\n");

                if (testCase.getErrorMessage() != null) {
                    html.append("            <div class=\"error-details\">\n")
                        .append("                <strong>Error:</strong> ").append(testCase.getErrorMessage()).append("\n")
                        .append("            </div>\n");
                }

                html.append("        </div>\n");
            }

            html.append("    </div>\n");
        }

        html.append("</body>\n")
            .append("</html>");

        return html.toString();
    }
}
