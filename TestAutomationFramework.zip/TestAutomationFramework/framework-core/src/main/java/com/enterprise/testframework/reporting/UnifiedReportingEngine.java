package com.enterprise.testframework.reporting;

import com.enterprise.testframework.interfaces.IReportingPlugin;
import com.enterprise.testframework.model.TestRunResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.plugin.core.PluginRegistry;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Unified reporting engine that orchestrates all reporting plugins
 */
@Component
public class UnifiedReportingEngine {

    private static final Logger logger = LoggerFactory.getLogger(UnifiedReportingEngine.class);

    @Autowired
    private PluginRegistry<IReportingPlugin, String> reportingPluginRegistry;

    @Autowired
    private FileBasedReporter fileBasedReporter;

    /**
     * Generate reports using all available reporting plugins
     */
    @Async("pluginExecutor")
    public CompletableFuture<Void> generateReports(TestRunResult testResult) {
        return CompletableFuture.runAsync(() -> {
            logger.info("Generating reports for execution: {}", testResult.getExecutionId());

            try {
                // Generate file-based reports first
                fileBasedReporter.generateReport(testResult);

                // Generate reports using all available plugins
                List<IReportingPlugin> plugins = reportingPluginRegistry.getPlugins();
                for (IReportingPlugin plugin : plugins) {
                    try {
                        logger.debug("Generating report using plugin: {}", plugin.getPluginName());
                        plugin.generateReport(testResult);
                    } catch (Exception e) {
                        logger.error("Error generating report with plugin {}: {}", plugin.getPluginName(), e.getMessage(), e);
                    }
                }

                // Finalize all reporting plugins
                for (IReportingPlugin plugin : plugins) {
                    try {
                        plugin.finalizeReporting();
                    } catch (Exception e) {
                        logger.error("Error finalizing reporting with plugin {}: {}", plugin.getPluginName(), e.getMessage(), e);
                    }
                }

                logger.info("Report generation completed for execution: {}", testResult.getExecutionId());

            } catch (Exception e) {
                logger.error("Error during report generation for execution {}: {}", testResult.getExecutionId(), e.getMessage(), e);
            }
        });
    }

    /**
     * Generate report using specific plugin
     */
    public void generateReportWithPlugin(TestRunResult testResult, String pluginName) {
        IReportingPlugin plugin = reportingPluginRegistry.getPluginFor(pluginName).orElse(null);
        if (plugin != null) {
            try {
                logger.info("Generating report using plugin: {}", pluginName);
                plugin.generateReport(testResult);
                plugin.finalizeReporting();
            } catch (Exception e) {
                logger.error("Error generating report with plugin {}: {}", pluginName, e.getMessage(), e);
            }
        } else {
            logger.warn("No reporting plugin found with name: {}", pluginName);
        }
    }

    /**
     * Get available reporting plugins
     */
    public List<String> getAvailablePlugins() {
        return reportingPluginRegistry.getPlugins().stream()
                .map(IReportingPlugin::getPluginName)
                .toList();
    }

    /**
     * Check if specific reporting plugin is available
     */
    public boolean isPluginAvailable(String pluginName) {
        return reportingPluginRegistry.getPluginFor(pluginName) != null;
    }
}
