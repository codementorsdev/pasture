package com.enterprise.testframework.service;

import com.enterprise.testframework.core.TestExecutionOrchestrator;
import com.enterprise.testframework.model.TestCase;
import com.enterprise.testframework.model.TestConfig;
import com.enterprise.testframework.model.TestRunResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Service layer for test execution operations
 */
@Service
public class TestExecutionService {

    @Autowired
    private TestExecutionOrchestrator orchestrator;

    /**
     * Execute tests asynchronously
     */
    public CompletableFuture<TestRunResult> executeTestsAsync(List<TestCase> testCases, TestConfig config) {
        return orchestrator.executeTests(testCases, config);
    }

    /**
     * Execute tests synchronously
     */
    public TestRunResult executeTests(List<TestCase> testCases, TestConfig config) {
        try {
            return orchestrator.executeTests(testCases, config).get();
        } catch (Exception e) {
            throw new RuntimeException("Test execution failed", e);
        }
    }

    /**
     * Get execution status
     */
    public TestRunResult getExecutionStatus(String executionId) {
        return orchestrator.getExecutionStatus(executionId);
    }

    /**
     * Get all active executions
     */
    public Map<String, TestRunResult> getActiveExecutions() {
        return orchestrator.getActiveExecutions();
    }

    /**
     * Check if execution is running
     */
    public boolean isExecutionRunning(String executionId) {
        TestRunResult result = getExecutionStatus(executionId);
        return result != null && !result.getStatus().isCompleted();
    }

    /**
     * Get execution summary
     */
    public Map<String, Object> getExecutionSummary(String executionId) {
        TestRunResult result = getExecutionStatus(executionId);
        if (result == null) {
            return null;
        }

        return Map.of(
                "executionId", result.getExecutionId(),
                "status", result.getStatus().name(),
                "totalTests", result.getTotalTests(),
                "passedTests", result.getPassedTests(),
                "failedTests", result.getFailedTests(),
                "skippedTests", result.getSkippedTests(),
                "successRate", result.getSuccessRate(),
                "duration", result.getFormattedDuration()
        );
    }
}
