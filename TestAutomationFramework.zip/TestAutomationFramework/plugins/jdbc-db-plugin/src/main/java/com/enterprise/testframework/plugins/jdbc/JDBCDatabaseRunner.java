package com.enterprise.testframework.plugins.jdbc;

import com.enterprise.testframework.interfaces.IRunnerPlugin;
import com.enterprise.testframework.model.TestCase;
import com.enterprise.testframework.model.TestConfig;
import com.enterprise.testframework.model.TestRunResult;
import com.enterprise.testframework.model.TestStatus;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * JDBC plugin for database testing
 */
@Component
public class JDBCDatabaseRunner implements IRunnerPlugin {

    private static final Logger logger = LoggerFactory.getLogger(JDBCDatabaseRunner.class);
    private static final String PLUGIN_NAME = "JDBC Database Runner";
    private DataSource dataSource;

    @Override
    public String getPluginName() {
        return PLUGIN_NAME;
    }

    @Override
    public List<String> getSupportedTestTypes() {
        return Arrays.asList("database", "db", "sql", "jdbc");
    }

    @Override
    public boolean supportsTestType(String testType) {
        return getSupportedTestTypes().contains(testType.toLowerCase());
    }

    @Override
    public boolean supports(String testType) {
        return supportsTestType(testType);
    }

    @Override
    public TestRunResult runTests(List<TestCase> testCases, TestConfig config) {
        logger.info("Starting JDBC database test execution for {} test cases", testCases.size());
        
        TestRunResult result = new TestRunResult();
        result.setExecutionId("db-" + System.currentTimeMillis());
        result.setStartTime(LocalDateTime.now());
        result.setStatus(TestStatus.RUNNING);
        result.setTestType("database");
        result.setPluginUsed(PLUGIN_NAME);
        result.setEnvironment(config.getEnvironment());

        try {
            // Setup database connection
            setupDatabaseConnection(config);
            
            int totalTests = testCases.size();
            int passedTests = 0;
            int failedTests = 0;
            int skippedTests = 0;

            for (TestCase testCase : testCases) {
                if (!testCase.isEnabled()) {
                    skippedTests++;
                    continue;
                }

                TestRunResult.TestCaseResult testResult = executeTestCase(testCase, config);
                result.addTestResult(testResult);

                switch (testResult.getStatus()) {
                    case PASSED:
                        passedTests++;
                        break;
                    case FAILED:
                        failedTests++;
                        if (!config.isContinueOnFailure()) {
                            logger.warn("Test case failed and continue-on-failure is disabled. Stopping execution.");
                            break;
                        }
                        break;
                    case SKIPPED:
                        skippedTests++;
                        break;
                }
            }

            result.setTotalTests(totalTests);
            result.setPassedTests(passedTests);
            result.setFailedTests(failedTests);
            result.setSkippedTests(skippedTests);
            result.setStatus(failedTests > 0 ? TestStatus.FAILED : TestStatus.PASSED);

        } catch (Exception e) {
            logger.error("Error during JDBC database test execution", e);
            result.setStatus(TestStatus.FAILED);
            result.setErrorMessage(e.getMessage());
        } finally {
            closeDatabaseConnection();
            result.setEndTime(LocalDateTime.now());
        }

        logger.info("JDBC database test execution completed. Status: {}", result.getStatus());
        return result;
    }

    private void setupDatabaseConnection(TestConfig config) throws SQLException {
        String dbUrl = config.getDbUrl();
        String dbUsername = config.getDbUsername();
        String dbPassword = config.getDbPassword();
        String dbDriver = config.getDbDriver();

        if (dbUrl == null) {
            throw new IllegalArgumentException("Database URL is required");
        }

        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl(dbUrl);
        
        if (dbUsername != null) {
            hikariConfig.setUsername(dbUsername);
        }
        
        if (dbPassword != null) {
            hikariConfig.setPassword(dbPassword);
        }
        
        if (dbDriver != null) {
            hikariConfig.setDriverClassName(dbDriver);
        }

        // Connection pool settings
        hikariConfig.setMaximumPoolSize(10);
        hikariConfig.setMinimumIdle(2);
        hikariConfig.setConnectionTimeout(30000);
        hikariConfig.setIdleTimeout(600000);
        hikariConfig.setMaxLifetime(1800000);

        dataSource = new HikariDataSource(hikariConfig);
        logger.info("Database connection established to: {}", dbUrl);
    }

    private void closeDatabaseConnection() {
        if (dataSource instanceof HikariDataSource) {
            ((HikariDataSource) dataSource).close();
            logger.info("Database connection closed");
        }
    }

    private TestRunResult.TestCaseResult executeTestCase(TestCase testCase, TestConfig config) {
        logger.debug("Executing database test case: {}", testCase.getName());
        
        TestRunResult.TestCaseResult result = new TestRunResult.TestCaseResult();
        result.setTestCaseName(testCase.getName());
        result.setTestCaseId(testCase.getId());
        result.setStartTime(LocalDateTime.now());

        Connection connection = null;
        try {
            connection = dataSource.getConnection();
            
            // Extract test parameters
            String sql = testCase.getPropertyAsString("sql");
            String expectedResult = testCase.getPropertyAsString("expectedResult");
            String expectedCount = testCase.getPropertyAsString("expectedCount");
            String testType = testCase.getPropertyAsString("testType");
            
            if (sql == null) {
                throw new IllegalArgumentException("Test case must specify 'sql' property");
            }

            // Execute based on test type
            if ("query".equalsIgnoreCase(testType)) {
                executeQueryTest(connection, sql, expectedResult, expectedCount, result);
            } else if ("update".equalsIgnoreCase(testType)) {
                executeUpdateTest(connection, sql, expectedCount, result);
            } else if ("schema".equalsIgnoreCase(testType)) {
                executeSchemaTest(connection, testCase, result);
            } else {
                // Default to query test
                executeQueryTest(connection, sql, expectedResult, expectedCount, result);
            }

            result.setStatus(TestStatus.PASSED);

        } catch (Exception e) {
            logger.error("Database test case failed: {}", testCase.getName(), e);
            result.setStatus(TestStatus.FAILED);
            result.setErrorMessage(e.getMessage());
            result.setStackTrace(getStackTrace(e));
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    logger.error("Error closing database connection", e);
                }
            }
            result.setEndTime(LocalDateTime.now());
        }

        return result;
    }

    private void executeQueryTest(Connection connection, String sql, String expectedResult, String expectedCount, TestRunResult.TestCaseResult result) throws SQLException {
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            
            // Count results
            int actualCount = 0;
            List<Map<String, Object>> results = new ArrayList<>();
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            while (rs.next()) {
                actualCount++;
                Map<String, Object> row = new HashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.put(metaData.getColumnName(i), rs.getObject(i));
                }
                results.add(row);
            }
            
            // Validate count if expected
            if (expectedCount != null) {
                int expCount = Integer.parseInt(expectedCount);
                if (actualCount != expCount) {
                    throw new AssertionError("Expected " + expCount + " rows but got " + actualCount);
                }
            }
            
            // Validate result content if expected
            if (expectedResult != null) {
                if (results.isEmpty()) {
                    throw new AssertionError("Expected result but query returned no rows");
                }
                
                // Simple validation - check if any row contains expected values
                boolean foundMatch = false;
                for (Map<String, Object> row : results) {
                    for (Object value : row.values()) {
                        if (value != null && value.toString().contains(expectedResult)) {
                            foundMatch = true;
                            break;
                        }
                    }
                    if (foundMatch) break;
                }
                
                if (!foundMatch) {
                    throw new AssertionError("Expected result '" + expectedResult + "' not found in query results");
                }
            }
            
            result.addAttribute("rowCount", actualCount);
            result.addAttribute("results", results);
        }
    }

    private void executeUpdateTest(Connection connection, String sql, String expectedCount, TestRunResult.TestCaseResult result) throws SQLException {
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            int affectedRows = stmt.executeUpdate();
            
            // Validate affected rows if expected
            if (expectedCount != null) {
                int expCount = Integer.parseInt(expectedCount);
                if (affectedRows != expCount) {
                    throw new AssertionError("Expected " + expCount + " affected rows but got " + affectedRows);
                }
            }
            
            result.addAttribute("affectedRows", affectedRows);
        }
    }

    private void executeSchemaTest(Connection connection, TestCase testCase, TestRunResult.TestCaseResult result) throws SQLException {
        String tableName = testCase.getPropertyAsString("tableName");
        String columnName = testCase.getPropertyAsString("columnName");
        String expectedDataType = testCase.getPropertyAsString("expectedDataType");
        
        if (tableName == null) {
            throw new IllegalArgumentException("Schema test requires 'tableName' property");
        }
        
        DatabaseMetaData metaData = connection.getMetaData();
        
        // Check if table exists
        try (ResultSet tables = metaData.getTables(null, null, tableName, new String[]{"TABLE"})) {
            if (!tables.next()) {
                throw new AssertionError("Table '" + tableName + "' does not exist");
            }
        }
        
        // Check column if specified
        if (columnName != null) {
            try (ResultSet columns = metaData.getColumns(null, null, tableName, columnName)) {
                if (!columns.next()) {
                    throw new AssertionError("Column '" + columnName + "' does not exist in table '" + tableName + "'");
                }
                
                // Check data type if specified
                if (expectedDataType != null) {
                    String actualDataType = columns.getString("TYPE_NAME");
                    if (!expectedDataType.equalsIgnoreCase(actualDataType)) {
                        throw new AssertionError("Expected data type '" + expectedDataType + "' but got '" + actualDataType + "'");
                    }
                }
            }
        }
        
        result.addAttribute("tableExists", true);
        if (columnName != null) {
            result.addAttribute("columnExists", true);
        }
    }

    private String getStackTrace(Exception e) {
        java.io.StringWriter sw = new java.io.StringWriter();
        java.io.PrintWriter pw = new java.io.PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }

    @Override
    public String getDescription() {
        return "JDBC plugin for automated database testing";
    }

    @Override
    public String getVersion() {
        return "1.0.0";
    }

    @Override
    public String getConfigurationSchema() {
        return """
            {
                "type": "object",
                "properties": {
                    "dbUrl": {
                        "type": "string",
                        "description": "Database JDBC URL"
                    },
                    "dbUsername": {
                        "type": "string",
                        "description": "Database username"
                    },
                    "dbPassword": {
                        "type": "string",
                        "description": "Database password"
                    },
                    "dbDriver": {
                        "type": "string",
                        "description": "Database driver class name"
                    }
                },
                "required": ["dbUrl"]
            }
            """;
    }
}
