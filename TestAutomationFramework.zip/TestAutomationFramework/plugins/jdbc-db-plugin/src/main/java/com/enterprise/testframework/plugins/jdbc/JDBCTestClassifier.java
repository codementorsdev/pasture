package com.enterprise.testframework.plugins.jdbc;

import com.enterprise.testframework.interfaces.ITestTypeClassifier;
import com.enterprise.testframework.model.TestCase;
import org.springframework.stereotype.Component;

/**
 * Classifier for JDBC database tests
 */
@Component
public class JDBCTestClassifier implements ITestTypeClassifier {

    private static final String PLUGIN_NAME = "JDBC Test Classifier";

    @Override
    public String getPluginName() {
        return PLUGIN_NAME;
    }

    @Override
    public String classifyTest(TestCase testCase) {
        // Check test case properties and metadata to determine if it's a database test
        
        // Check test name
        String testName = testCase.getName().toLowerCase();
        if (testName.contains("db") || testName.contains("database") || testName.contains("sql") || 
            testName.contains("jdbc") || testName.contains("table") || testName.contains("schema")) {
            return "database";
        }
        
        // Check test type
        if (testCase.getType() != null) {
            String type = testCase.getType().toLowerCase();
            if (type.equals("database") || type.equals("db") || type.equals("sql") || type.equals("jdbc")) {
                return "database";
            }
        }
        
        // Check file path
        if (testCase.getFilePath() != null) {
            String filePath = testCase.getFilePath().toLowerCase();
            if (filePath.contains("db") || filePath.contains("database") || filePath.contains("sql") || filePath.contains("jdbc")) {
                return "database";
            }
        }
        
        // Check properties
        if (testCase.getProperties() != null) {
            // Check for SQL property
            if (testCase.getProperties().containsKey("sql")) {
                return "database";
            }
            
            // Check for database connection properties
            if (testCase.getProperties().containsKey("dbUrl") ||
                testCase.getProperties().containsKey("databaseUrl") ||
                testCase.getProperties().containsKey("jdbcUrl") ||
                testCase.getProperties().containsKey("connectionString")) {
                return "database";
            }
            
            // Check for database-specific properties
            if (testCase.getProperties().containsKey("tableName") ||
                testCase.getProperties().containsKey("schema") ||
                testCase.getProperties().containsKey("query") ||
                testCase.getProperties().containsKey("expectedCount") ||
                testCase.getProperties().containsKey("expectedResult")) {
                return "database";
            }
            
            // Check for JDBC-specific properties
            if (testCase.getProperties().containsKey("jdbc") ||
                testCase.getProperties().containsKey("driver") ||
                testCase.getProperties().containsKey("dbDriver")) {
                return "database";
            }
        }
        
        // Check tags
        if (testCase.getTags() != null) {
            for (String tag : testCase.getTags()) {
                String lowerTag = tag.toLowerCase();
                if (lowerTag.equals("database") || lowerTag.equals("db") || lowerTag.equals("sql") || 
                    lowerTag.equals("jdbc") || lowerTag.equals("persistence") || lowerTag.equals("data")) {
                    return "database";
                }
            }
        }
        
        return null; // Cannot classify as database test
    }

    @Override
    public double getClassificationConfidence(TestCase testCase) {
        String classification = classifyTest(testCase);
        if (classification != null) {
            // Calculate confidence based on how many indicators we found
            double confidence = 0.0;
            
            String testName = testCase.getName().toLowerCase();
            if (testName.contains("db") || testName.contains("database") || testName.contains("sql")) {
                confidence += 0.3;
            }
            
            if (testCase.getType() != null && testCase.getType().equalsIgnoreCase("database")) {
                confidence += 0.4;
            }
            
            if (testCase.getProperties() != null) {
                if (testCase.getProperties().containsKey("sql")) {
                    confidence += 0.4;
                }
                if (testCase.getProperties().containsKey("dbUrl")) {
                    confidence += 0.3;
                }
                if (testCase.getProperties().containsKey("tableName")) {
                    confidence += 0.2;
                }
            }
            
            return Math.min(confidence, 1.0);
        }
        return 0.0;
    }

    @Override
    public String[] getSupportedTestTypes() {
        return new String[]{"database", "db", "sql", "jdbc"};
    }

    @Override
    public boolean supports(String testType) {
        return "database".equals(testType) || "db".equals(testType) || "sql".equals(testType) || "jdbc".equals(testType);
    }

    @Override
    public int getPriority() {
        return 10; // High priority for database test classification
    }

    @Override
    public String getDescription() {
        return "Classifier for JDBC database tests";
    }

    @Override
    public String getVersion() {
        return "1.0.0";
    }
}
