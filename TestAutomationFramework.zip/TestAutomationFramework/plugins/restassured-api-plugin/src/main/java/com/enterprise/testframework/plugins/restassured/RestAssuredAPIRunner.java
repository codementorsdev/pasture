package com.enterprise.testframework.plugins.restassured;

import com.enterprise.testframework.interfaces.IRunnerPlugin;
import com.enterprise.testframework.model.TestCase;
import com.enterprise.testframework.model.TestConfig;
import com.enterprise.testframework.model.TestRunResult;
import com.enterprise.testframework.model.TestStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * RestAssured plugin for API testing
 */
@Component
public class RestAssuredAPIRunner implements IRunnerPlugin {

    private static final Logger logger = LoggerFactory.getLogger(RestAssuredAPIRunner.class);
    private static final String PLUGIN_NAME = "RestAssured API Runner";
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String getPluginName() {
        return PLUGIN_NAME;
    }

    @Override
    public List<String> getSupportedTestTypes() {
        return Arrays.asList("api", "rest", "http", "web-service");
    }

    @Override
    public boolean supportsTestType(String testType) {
        return getSupportedTestTypes().contains(testType.toLowerCase());
    }

    @Override
    public boolean supports(String testType) {
        return supportsTestType(testType);
    }

    @Override
    public TestRunResult runTests(List<TestCase> testCases, TestConfig config) {
        logger.info("Starting RestAssured API test execution for {} test cases", testCases.size());
        
        TestRunResult result = new TestRunResult();
        result.setExecutionId("api-" + System.currentTimeMillis());
        result.setStartTime(LocalDateTime.now());
        result.setStatus(TestStatus.RUNNING);
        result.setTestType("api");
        result.setPluginUsed(PLUGIN_NAME);
        result.setEnvironment(config.getEnvironment());

        try {
            // Setup RestAssured configuration
            setupRestAssuredConfig(config);
            
            int totalTests = testCases.size();
            int passedTests = 0;
            int failedTests = 0;
            int skippedTests = 0;

            for (TestCase testCase : testCases) {
                if (!testCase.isEnabled()) {
                    skippedTests++;
                    continue;
                }

                TestRunResult.TestCaseResult testResult = executeTestCase(testCase, config);
                result.addTestResult(testResult);

                switch (testResult.getStatus()) {
                    case PASSED:
                        passedTests++;
                        break;
                    case FAILED:
                        failedTests++;
                        if (!config.isContinueOnFailure()) {
                            logger.warn("Test case failed and continue-on-failure is disabled. Stopping execution.");
                            break;
                        }
                        break;
                    case SKIPPED:
                        skippedTests++;
                        break;
                }
            }

            result.setTotalTests(totalTests);
            result.setPassedTests(passedTests);
            result.setFailedTests(failedTests);
            result.setSkippedTests(skippedTests);
            result.setStatus(failedTests > 0 ? TestStatus.FAILED : TestStatus.PASSED);

        } catch (Exception e) {
            logger.error("Error during RestAssured API test execution", e);
            result.setStatus(TestStatus.FAILED);
            result.setErrorMessage(e.getMessage());
        } finally {
            result.setEndTime(LocalDateTime.now());
        }

        logger.info("RestAssured API test execution completed. Status: {}", result.getStatus());
        return result;
    }

    private void setupRestAssuredConfig(TestConfig config) {
        // Set base URI if provided
        if (config.getBaseUrl() != null) {
            RestAssured.baseURI = config.getBaseUrl();
            logger.info("Set RestAssured base URI to: {}", config.getBaseUrl());
        }

        // Set default content type
        RestAssured.defaultParser = io.restassured.parsing.Parser.JSON;
        
        // Set timeout
        RestAssured.config = RestAssured.config()
            .httpClient(io.restassured.config.HttpClientConfig.httpClientConfig()
                .setParam("http.socket.timeout", config.getApiTimeoutMillis())
                .setParam("http.connection.timeout", config.getApiTimeoutMillis()));
    }

    private TestRunResult.TestCaseResult executeTestCase(TestCase testCase, TestConfig config) {
        logger.debug("Executing API test case: {}", testCase.getName());
        
        TestRunResult.TestCaseResult result = new TestRunResult.TestCaseResult();
        result.setTestCaseName(testCase.getName());
        result.setTestCaseId(testCase.getId());
        result.setStartTime(LocalDateTime.now());

        try {
            // Extract test parameters
            String method = testCase.getPropertyAsString("method");
            String endpoint = testCase.getPropertyAsString("endpoint");
            String expectedStatus = testCase.getPropertyAsString("expectedStatus");
            String requestBody = testCase.getPropertyAsString("requestBody");
            String expectedResponse = testCase.getPropertyAsString("expectedResponse");
            String contentType = testCase.getPropertyAsString("contentType");

            if (method == null || endpoint == null) {
                throw new IllegalArgumentException("Test case must specify 'method' and 'endpoint' properties");
            }

            // Build request specification
            RequestSpecification request = RestAssured.given();

            // Add headers from config
            if (config.getHeaders() != null) {
                for (Map.Entry<String, String> header : config.getHeaders().entrySet()) {
                    request.header(header.getKey(), header.getValue());
                }
            }

            // Add headers from test case
            Object headersObj = testCase.getProperty("headers");
            if (headersObj instanceof Map) {
                Map<String, String> headers = (Map<String, String>) headersObj;
                for (Map.Entry<String, String> header : headers.entrySet()) {
                    request.header(header.getKey(), header.getValue());
                }
            }

            // Set content type
            if (contentType != null) {
                request.contentType(contentType);
            } else {
                request.contentType(ContentType.JSON);
            }

            // Add request body if provided
            if (requestBody != null) {
                request.body(requestBody);
            }

            // Execute request
            Response response = executeRequest(request, method, endpoint);

            // Log response details
            logger.debug("API Response - Status: {}, Body: {}", response.getStatusCode(), response.getBody().asString());

            // Validate response
            validateResponse(response, testCase, expectedStatus, expectedResponse);

            result.setStatus(TestStatus.PASSED);
            result.addAttribute("statusCode", response.getStatusCode());
            result.addAttribute("responseTime", response.getTime());
            result.addAttribute("contentType", response.getContentType());

        } catch (Exception e) {
            logger.error("API test case failed: {}", testCase.getName(), e);
            result.setStatus(TestStatus.FAILED);
            result.setErrorMessage(e.getMessage());
            result.setStackTrace(getStackTrace(e));
        } finally {
            result.setEndTime(LocalDateTime.now());
        }

        return result;
    }

    private Response executeRequest(RequestSpecification request, String method, String endpoint) {
        switch (method.toUpperCase()) {
            case "GET":
                return request.get(endpoint);
            case "POST":
                return request.post(endpoint);
            case "PUT":
                return request.put(endpoint);
            case "DELETE":
                return request.delete(endpoint);
            case "PATCH":
                return request.patch(endpoint);
            case "HEAD":
                return request.head(endpoint);
            case "OPTIONS":
                return request.options(endpoint);
            default:
                throw new IllegalArgumentException("Unsupported HTTP method: " + method);
        }
    }

    private void validateResponse(Response response, TestCase testCase, String expectedStatus, String expectedResponse) {
        // Validate status code
        if (expectedStatus != null) {
            int expectedStatusCode = Integer.parseInt(expectedStatus);
            if (response.getStatusCode() != expectedStatusCode) {
                throw new AssertionError("Expected status code " + expectedStatusCode + " but got " + response.getStatusCode());
            }
        }

        // Validate response body
        if (expectedResponse != null) {
            String actualResponse = response.getBody().asString();
            
            // Try JSON comparison if both are valid JSON
            try {
                Object expectedJson = objectMapper.readValue(expectedResponse, Object.class);
                Object actualJson = objectMapper.readValue(actualResponse, Object.class);
                
                if (!expectedJson.equals(actualJson)) {
                    throw new AssertionError("Response body mismatch. Expected: " + expectedResponse + ", Actual: " + actualResponse);
                }
            } catch (Exception e) {
                // Fall back to string comparison
                if (!actualResponse.equals(expectedResponse)) {
                    throw new AssertionError("Response body mismatch. Expected: " + expectedResponse + ", Actual: " + actualResponse);
                }
            }
        }

        // Validate response schema if provided
        String expectedSchema = testCase.getPropertyAsString("expectedSchema");
        if (expectedSchema != null) {
            try {
                response.then().assertThat().body(io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema(expectedSchema));
            } catch (Exception e) {
                throw new AssertionError("Response schema validation failed: " + e.getMessage());
            }
        }

        // Validate response time if specified
        Integer maxResponseTime = testCase.getPropertyAsInteger("maxResponseTime");
        if (maxResponseTime != null && response.getTime() > maxResponseTime) {
            throw new AssertionError("Response time " + response.getTime() + "ms exceeded maximum " + maxResponseTime + "ms");
        }

        // Validate response headers if specified
        Object expectedHeadersObj = testCase.getProperty("expectedHeaders");
        if (expectedHeadersObj instanceof Map) {
            Map<String, String> expectedHeaders = (Map<String, String>) expectedHeadersObj;
            for (Map.Entry<String, String> header : expectedHeaders.entrySet()) {
                String actualHeaderValue = response.getHeader(header.getKey());
                if (!header.getValue().equals(actualHeaderValue)) {
                    throw new AssertionError("Header '" + header.getKey() + "' mismatch. Expected: " + header.getValue() + ", Actual: " + actualHeaderValue);
                }
            }
        }
    }

    private String getStackTrace(Exception e) {
        java.io.StringWriter sw = new java.io.StringWriter();
        java.io.PrintWriter pw = new java.io.PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }

    @Override
    public String getDescription() {
        return "RestAssured plugin for automated API testing";
    }

    @Override
    public String getVersion() {
        return "1.0.0";
    }

    @Override
    public String getConfigurationSchema() {
        return """
            {
                "type": "object",
                "properties": {
                    "baseUrl": {
                        "type": "string",
                        "description": "Base URL for API endpoints"
                    },
                    "headers": {
                        "type": "object",
                        "description": "Default headers for all requests"
                    },
                    "apiTimeoutMillis": {
                        "type": "integer",
                        "default": 10000,
                        "description": "API request timeout in milliseconds"
                    }
                }
            }
            """;
    }
}
