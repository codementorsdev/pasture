package com.enterprise.testframework.plugins.restassured;

import com.enterprise.testframework.interfaces.ITestTypeClassifier;
import com.enterprise.testframework.model.TestCase;
import org.springframework.stereotype.Component;

/**
 * Classifier for RestAssured API tests
 */
@Component
public class RestAssuredTestClassifier implements ITestTypeClassifier {

    private static final String PLUGIN_NAME = "RestAssured Test Classifier";

    @Override
    public String getPluginName() {
        return PLUGIN_NAME;
    }

    @Override
    public String classifyTest(TestCase testCase) {
        // Check test case properties and metadata to determine if it's an API test
        
        // Check test name
        String testName = testCase.getName().toLowerCase();
        if (testName.contains("api") || testName.contains("rest") || testName.contains("http") || 
            testName.contains("service") || testName.contains("endpoint")) {
            return "api";
        }
        
        // Check test type
        if (testCase.getType() != null) {
            String type = testCase.getType().toLowerCase();
            if (type.equals("api") || type.equals("rest") || type.equals("http") || type.equals("web-service")) {
                return "api";
            }
        }
        
        // Check file path
        if (testCase.getFilePath() != null) {
            String filePath = testCase.getFilePath().toLowerCase();
            if (filePath.contains("api") || filePath.contains("rest") || filePath.contains("http") || filePath.contains("service")) {
                return "api";
            }
        }
        
        // Check properties
        if (testCase.getProperties() != null) {
            // Check for HTTP method property
            if (testCase.getProperties().containsKey("method")) {
                String method = testCase.getPropertyAsString("method");
                if (method != null && isHttpMethod(method)) {
                    return "api";
                }
            }
            
            // Check for endpoint or URL property
            if (testCase.getProperties().containsKey("endpoint") || 
                testCase.getProperties().containsKey("url") ||
                testCase.getProperties().containsKey("apiUrl") ||
                testCase.getProperties().containsKey("serviceUrl")) {
                return "api";
            }
            
            // Check for request/response properties
            if (testCase.getProperties().containsKey("requestBody") ||
                testCase.getProperties().containsKey("expectedResponse") ||
                testCase.getProperties().containsKey("expectedStatus") ||
                testCase.getProperties().containsKey("headers")) {
                return "api";
            }
            
            // Check for REST-specific properties
            if (testCase.getProperties().containsKey("restassured") ||
                testCase.getProperties().containsKey("contentType") ||
                testCase.getProperties().containsKey("accept")) {
                return "api";
            }
        }
        
        // Check tags
        if (testCase.getTags() != null) {
            for (String tag : testCase.getTags()) {
                String lowerTag = tag.toLowerCase();
                if (lowerTag.equals("api") || lowerTag.equals("rest") || lowerTag.equals("http") || 
                    lowerTag.equals("service") || lowerTag.equals("integration")) {
                    return "api";
                }
            }
        }
        
        return null; // Cannot classify as API test
    }

    private boolean isHttpMethod(String method) {
        String upperMethod = method.toUpperCase();
        return upperMethod.equals("GET") || upperMethod.equals("POST") || upperMethod.equals("PUT") || 
               upperMethod.equals("DELETE") || upperMethod.equals("PATCH") || upperMethod.equals("HEAD") || 
               upperMethod.equals("OPTIONS");
    }

    @Override
    public double getClassificationConfidence(TestCase testCase) {
        String classification = classifyTest(testCase);
        if (classification != null) {
            // Calculate confidence based on how many indicators we found
            double confidence = 0.0;
            
            String testName = testCase.getName().toLowerCase();
            if (testName.contains("api") || testName.contains("rest") || testName.contains("http")) {
                confidence += 0.3;
            }
            
            if (testCase.getType() != null && testCase.getType().equalsIgnoreCase("api")) {
                confidence += 0.4;
            }
            
            if (testCase.getProperties() != null) {
                if (testCase.getProperties().containsKey("method")) {
                    confidence += 0.3;
                }
                if (testCase.getProperties().containsKey("endpoint")) {
                    confidence += 0.3;
                }
                if (testCase.getProperties().containsKey("expectedStatus")) {
                    confidence += 0.2;
                }
            }
            
            return Math.min(confidence, 1.0);
        }
        return 0.0;
    }

    @Override
    public String[] getSupportedTestTypes() {
        return new String[]{"api", "rest", "http", "web-service"};
    }

    @Override
    public boolean supports(String testType) {
        return "api".equals(testType) || "rest".equals(testType) || "http".equals(testType) || "web-service".equals(testType);
    }

    @Override
    public int getPriority() {
        return 10; // High priority for API test classification
    }

    @Override
    public String getDescription() {
        return "Classifier for RestAssured API tests";
    }

    @Override
    public String getVersion() {
        return "1.0.0";
    }
}
