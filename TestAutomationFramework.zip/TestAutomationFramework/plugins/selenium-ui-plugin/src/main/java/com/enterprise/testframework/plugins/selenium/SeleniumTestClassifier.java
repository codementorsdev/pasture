package com.enterprise.testframework.plugins.selenium;

import com.enterprise.testframework.interfaces.ITestTypeClassifier;
import com.enterprise.testframework.model.TestCase;
import org.springframework.stereotype.Component;

/**
 * Classifier for Selenium UI tests
 */
@Component
public class SeleniumTestClassifier implements ITestTypeClassifier {

    private static final String PLUGIN_NAME = "Selenium Test Classifier";

    @Override
    public String getPluginName() {
        return PLUGIN_NAME;
    }

    @Override
    public String classifyTest(TestCase testCase) {
        // Check test case properties and metadata to determine if it's a UI test
        
        // Check test name
        String testName = testCase.getName().toLowerCase();
        if (testName.contains("ui") || testName.contains("web") || testName.contains("selenium") || testName.contains("browser")) {
            return "ui";
        }
        
        // Check test type
        if (testCase.getType() != null) {
            String type = testCase.getType().toLowerCase();
            if (type.equals("ui") || type.equals("web") || type.equals("selenium")) {
                return "ui";
            }
        }
        
        // Check file path
        if (testCase.getFilePath() != null) {
            String filePath = testCase.getFilePath().toLowerCase();
            if (filePath.contains("ui") || filePath.contains("web") || filePath.contains("selenium")) {
                return "ui";
            }
        }
        
        // Check properties
        if (testCase.getProperties() != null) {
            // Check for URL property (common in UI tests)
            if (testCase.getProperties().containsKey("url") || 
                testCase.getProperties().containsKey("baseUrl") ||
                testCase.getProperties().containsKey("webUrl")) {
                return "ui";
            }
            
            // Check for browser property
            if (testCase.getProperties().containsKey("browser")) {
                return "ui";
            }
            
            // Check for Selenium-specific properties
            if (testCase.getProperties().containsKey("driver") ||
                testCase.getProperties().containsKey("webdriver") ||
                testCase.getProperties().containsKey("selenium")) {
                return "ui";
            }
        }
        
        // Check tags
        if (testCase.getTags() != null) {
            for (String tag : testCase.getTags()) {
                String lowerTag = tag.toLowerCase();
                if (lowerTag.equals("ui") || lowerTag.equals("web") || lowerTag.equals("selenium") || lowerTag.equals("browser")) {
                    return "ui";
                }
            }
        }
        
        return null; // Cannot classify as UI test
    }

    @Override
    public double getClassificationConfidence(TestCase testCase) {
        String classification = classifyTest(testCase);
        if (classification != null) {
            // Calculate confidence based on how many indicators we found
            double confidence = 0.0;
            
            String testName = testCase.getName().toLowerCase();
            if (testName.contains("ui") || testName.contains("web") || testName.contains("selenium")) {
                confidence += 0.3;
            }
            
            if (testCase.getType() != null && testCase.getType().equalsIgnoreCase("ui")) {
                confidence += 0.4;
            }
            
            if (testCase.getProperties() != null) {
                if (testCase.getProperties().containsKey("url")) {
                    confidence += 0.3;
                }
                if (testCase.getProperties().containsKey("browser")) {
                    confidence += 0.2;
                }
            }
            
            return Math.min(confidence, 1.0);
        }
        return 0.0;
    }

    @Override
    public String[] getSupportedTestTypes() {
        return new String[]{"ui", "web", "selenium"};
    }

    @Override
    public boolean supports(String testType) {
        return "ui".equals(testType) || "web".equals(testType) || "selenium".equals(testType);
    }

    @Override
    public int getPriority() {
        return 10; // High priority for UI test classification
    }

    @Override
    public String getDescription() {
        return "Classifier for Selenium UI tests";
    }

    @Override
    public String getVersion() {
        return "1.0.0";
    }
}
