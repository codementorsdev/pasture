# Enterprise Test Automation Framework

## Overview

This is a modular, plugin-based test automation framework built with Java Spring Boot that supports multiple testing types through a unified architecture. The framework provides a centralized orchestration engine that can execute UI, API, Database, Performance, and ETL tests through extensible plugins.

## System Architecture

### Core Components
- **Spring Boot Application**: Central orchestration engine managing plugin lifecycle and test execution
- **Plugin System**: Extensible architecture using Spring SPI for runtime plugin integration
- **Test Execution Orchestrator**: Intelligent routing and parallel execution of tests
- **Unified Reporting**: Consolidated reporting across all test types

### Plugin Architecture
The framework uses a plugin-based architecture with the following key interfaces:
- `IRunnerPlugin`: Handles execution for specific test types (UI, API, DB, Performance, ETL)
- `ITestTypeClassifier`: Categorizes and detects test types
- `IReportingPlugin`: Normalizes results from different test types
- `IEnvironmentPlugin`, `ITestDataPlugin`, `ICiCdPlugin`: Additional plugin categories

## Key Components

### 1. Core Framework Engine
- **Purpose**: Centralized test execution orchestrator
- **Technologies**: Spring Boot 3.x, Java
- **Responsibilities**:
  - Plugin discovery and lifecycle management
  - Test discovery and dispatching
  - Configuration and context management
  - Execution strategy selection
  - Event bus for plugin communications

### 2. Supported Test Types
- **UI Testing**: Selenium and Playwright integration with browser orchestration
- **API Testing**: RestAssured, Karate, and Postman CLI integration
- **Database Testing**: SQL assertions, Flyway/Liquibase validation, data integrity checks
- **Performance Testing**: JMeter CLI support, Gatling script execution, metrics capture
- **ETL Testing**: Data source comparison, pipeline validation, schema checks

### 3. Execution Engine
- **Parallel Execution**: Concurrent test execution across multiple plugins
- **Docker Support**: Containerized execution environment
- **Remote Execution**: gRPC and REST API support for distributed testing
- **Message Queuing**: RabbitMQ/Kafka for scalable test queuing (planned)

### 4. Reporting System
- **Unified Format**: Normalizes results across all test types
- **Multiple Formats**: JSON, XML, and HTML report generation
- **Third-party Integration**: Hooks for Allure and ReportPortal dashboards

## Data Flow

1. **Test Discovery**: Framework scans for test cases and classifies them by type
2. **Plugin Selection**: Appropriate runner plugins are selected based on test metadata
3. **Execution Orchestration**: Tests are dispatched to plugins with parallel execution support
4. **Result Collection**: Plugin results are normalized and aggregated
5. **Report Generation**: Unified reports are generated in multiple formats

## External Dependencies

### Core Dependencies
- Spring Boot 3.x (Application framework)
- Spring SPI (Plugin system)
- Docker (Containerization)

### Plugin Dependencies
- **UI Testing**: Selenium WebDriver, Playwright
- **API Testing**: RestAssured, Karate DSL
- **Database**: JDBC drivers, Flyway, Liquibase
- **Performance**: JMeter, Gatling
- **Reporting**: Allure, ReportPortal

### Infrastructure (Planned)
- RabbitMQ/Kafka (Message queuing)
- Kubernetes (Orchestration)
- gRPC (Remote execution)

## Deployment Strategy

### Container-Based Deployment
- Docker containers for isolated test execution
- Kubernetes support for scalable deployment
- Docker Compose for local development

### API Interfaces
- **REST API**: Programmatic test execution and management
- **CLI Interface**: Command-line tool for test execution
- **gRPC**: High-performance remote execution protocol

### Execution Modes
- **Local Execution**: Direct execution on local machine
- **Containerized**: Docker-based isolated execution
- **Distributed**: Remote execution via agents and message queues

## Changelog

```
Changelog:
- July 03, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```